# guideXOS Server v0.2 Dual-Monitor Implementation Track

Validated through `2026-07-16`. The base persistence proof is complete, and this milestone adds bounded QEMU-only per-output logical-resolution selection with transactional resource rebuilds and separate-launch restoration. The intentional removal of the duplicate hosted synthetic document remains preserved.

## Purpose

- Prove the hosted compositor and display model can represent a synthetic second monitor without changing the default hosted path.
- Validate virtual desktop bounds, viewport selection, render-target accounting, taskbar routing, and input mapping in a controlled hosted validation lane.
- Prove the QEMU-only virtio-gpu dual-output compositor snapshot path while preserving the static diagnostic patterns and keeping real hardware GPU work out of scope.

## Safety Boundary

- QEMU virtio-gpu work is allowed in this branch, but only through the x86_64 diagnostic probe gate.
- The probe rendering path stays QEMU-only and does not activate on normal production bare-metal boots.
- Real bare-metal Intel/onboard GPU work is not allowed yet.
- REAL HARDWARE GPU/MMIO ENABLEMENT IS MULE TERRITORY AND REQUIRES A SEPARATE SAFETY CHECKPOINT.
- Real hardware GPU mode-setting, MMIO probing, scanout enabling, and display register programming remain out of scope for this pass.

## Current Probe Status

- Stage A is visually confirmed on scanout 0.
- The latest confirmed scanout-0 capture is `logs\qemu-display-probe-20260712-214504\virtio-gpu-stageA\captures\scanout0-stageA-gpu0-head0.png`.
- The Stage A physical backing audit validated one mem entry, one contiguous physical run, `coveredBytes=4096000`, and `physicalCoverageValid=yes`.
- Stage B renders a distinct second pattern on scanout 1, with the latest captures at `logs\qemu-display-probe-20260712-214504\virtio-gpu-stageB\captures\scanout0-stageB.png` and `logs\qemu-display-probe-20260712-214504\virtio-gpu-stageB\captures\scanout1-stageB.png`.
- The first single-shot compositor frame now renders into both virtio-gpu resources with target-local clipping, a primary-only taskbar, and distinct visual evidence for each viewport.
- The controlled QEMU-only live path now repeats that compositor presentation through the normal desktop update cadence, with dirty-generation skipping, a hard 10 FPS cap, and a bounded 60-attempt proof mode.
- The backend-independent display input mapper and QEMU-only bounded input proof are now implemented. The current launcher inventory identifies the guest path as PS/2-relative; it does not silently assume an absolute tablet.
- Dual-output rendering is proven, while `GET_DISPLAY_INFO` still reports `enabledScanoutsAfter=1` and `post-render scanout[1] enabled=no`; that connector state is tracked separately from resource assignment and presentation readiness.
- The output inventory now reports two operational outputs, two monitors, two backed render targets, and presentation confirmation for scanout 1 when capture validation is available.
- Latest input-routing run root: `logs\qemu-display-probe-20260713-121002\`.
- The typed guest command/response bridge, authoritative configuration service, bounded safe-point transactions, hosted adapter, and bare-metal adapter are now implemented.
- The QEMU-only proof coordinator now queries active state, proves Extend -> Mirror -> Extend, switches primary/taskbar routing to Display 2 and back, and injects one validation failure to prove rollback and presentation resume.

## Display Options Real-Output Configuration Track

The existing Display Options persistence model is now the requested display
configuration. Detected backend inventory, requested settings, and active
applied settings are separate records; a failed request cannot overwrite the
active layout. The QEMU-only virtio-gpu bridge supplies stable monitor/output
identity and assigned geometry, while resource IDs, backing addresses, and
connector state remain runtime diagnostics rather than persisted authority.

Display Options consumes operational virtio-gpu outputs when the gated backend
inventory is published. Output 2 is shown as `VirtIO-GPU Output 2` and
`Operational` even when `connectorEnabled` is false; connector state is shown
on its own diagnostic line. If the backend inventory is unavailable, the
existing hosted synthetic and single-framebuffer paths remain active.

For this milestone, “resolution” means a QEMU logical scanout size: the
VirtIO-GPU 2D resource, stable backing store, scanout rectangle, monitor
geometry, render target, and compositor `PixelSurface` all use the selected
width and height. It is not a physical timing, refresh-rate, EDID mode, host
display mode, rotation, or real-hardware modeset. The bounded catalog is
`qemu-1280x800`, `qemu-1024x768`, and `qemu-800x600`, with checked 32-bit
backing arithmetic and per-output/total memory limits. Display Options shows
`Refresh rate: Not available` and `Rotation: Not available` for this backend.

Apply is a bounded transaction: it snapshots the active configuration, pauses
new presentation, waits for the current synchronous presentation to become
idle, validates the request, rebuilds monitor/view/target geometry, clamps
windows and cursor-related capture state, presents a validation frame, and
only then commits persistence. Failure restores the prior desktop state and
reports the exact blocker, with rollback/fallback status in the compact
summary. UI edits are not live-previewed: Apply commits them, OK follows the
existing window flow, and Cancel restores the last applied selection.

Extend uses persisted virtual origins and derives the complete requested layout
before changing any scanout. Equal 1280x800 outputs produce `2560x800`;
mixed Display 1 `1280x800` plus Display 2 `1024x768` produces Display 2 at
`1280,0` and a `2304x800` virtual desktop. The cursor clamps to the union of
monitor rectangles, so the lower 32-pixel region outside Display 2 is not a
dead display area. Mirror requires identical active dimensions, uses one
logical viewport at `0,0`, and rejects mismatched requests with
`MirrorGeometryIncompatible`. Primary selection updates the taskbar monitor
and selected monitor work area without silently reordering the arrangement.
Saved output identities are reconciled by stable backend/output identity;
requested logical dimensions are not connector identity.

The shared configuration transaction and source/runtime contract smoke are:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-display-options.ps1
powershell -ExecutionPolicy Bypass -File scripts\smoke-qemu-display-options-runtime.ps1
```

The QEMU runtime wrapper reuses the bounded live virtio-gpu proof to verify the
two operational targets, both captures, validation counters, and zero target
failures while the configuration transaction remains bounded and gated.

The hosted Display Options surface and the bare-metal QEMU app now submit the
same fixed-size `DisplayConfigurationCommand` contract to
`DisplayConfigurationService`. The service owns serialization, active-state
snapshots, pause/resume, target-layout application, input bounds, primary and
taskbar routing, validation, rollback, last-known-good state, and persistence
commit. The current app model runs callbacks on the desktop owner path, so the
service processes its single bounded mutation slot at that compositor-safe
point; the explicit safe-point hook remains available for a future process-IPC
adapter.

The runtime wrapper proves the real QEMU endpoint rather than calling private
transaction helpers. The authoritative service owns prepare-before-replace:
new backing, physical coverage audit, nonzero unique resource ID, resource
creation/attachment, provisional validation frame, scanout bind, post-bind
validation, atomic inventory publication, active-state commit, and only then
old-resource cleanup. A failure before or after a scanout bind releases
provisional resources and, when needed, rebinds and presents the old resources.
Display Options never owns these GPU operations.

## Typed Display Configuration Control Plane

`display_configuration_command.h` is the kernel-safe, backend-neutral contract.
It contains a version, structure size, request ID, command type, flags, a
fixed output arrangement, and no pointers, UI references, resource IDs,
physical addresses, backing addresses, or MMIO fields. It supports queries,
ApplyConfiguration, RestoreLastKnownGood, and ForceValidationFrame. Responses
carry accepted/completed/success state, stable result codes, validation,
pause/resume, target rebuild, rollback, persistence, detected and active
snapshots, and bounded diagnostics.

The service has one serialized mutation slot. Queries read stable snapshots;
additional mutations receive `BackendBusy`. Apply uses the existing
transaction sequence: snapshot, validate, pause presentation, wait boundedly,
rebuild monitor/target geometry, update virtual desktop and input bounds,
route primary/taskbar state, render and flush a validation frame, resume, then
persist. Any failure restores the previous layout and reports rollback success
or failure. The one-shot injected validation failure is accepted only by the
explicit QEMU control-proof build gate and cannot be enabled by normal boots.

Hosted and bare-metal Display Options are thin adapters. Apply leaves the
window open, OK closes only after success, and Cancel discards local edits and
reloads active state without submitting a backend rollback. Window generation,
request ID, and command type prevent stale responses from updating a newly
opened window.

The bounded proof coordinator emits request/response diagnostics and host-QMP
capture markers for `initial`, `mirror`, `extend`, `primary-2`, `primary-1`,
and `rollback`. QMP remains host-harness-only for QEMU lifecycle, screenshots,
and evidence collection; it is not guest IPC.

### Runtime control proof

The initial active query must report the operational `virtio-gpu` backend, two
outputs, Extend mode, Display 1 primary, and the runtime virtual desktop. The
successful proof then records:

- Extend -> Mirror: both independent resources stay bound, both target
  viewports become `0,0`, the logical desktop uses the current 1280x800
  geometry, validation succeeds, and presentation resumes.
- Mirror -> Extend: Monitor 2 returns to the right at the runtime-equivalent
  origin, the virtual desktop returns to the extended width, and input bounds
  are restored.
- Primary Display 2 -> Display 1: taskbar ownership follows the primary
  monitor, existing valid windows remain usable, and the active response is
  checked after each apply.
- One-shot validation failure: the request is accepted, presentation pauses,
  rollback restores the previous Extend/primary-1 state, persistence is not
  committed for the failed request, and presentation resumes.

The separate-launch persistence restoration proof is the next milestone.

## Implementation Roadmap

1. Hosted synthetic validation complete.
1. Hosted two-window synthetic output complete.
1. QEMU GOP/backend diagnostics complete.
1. virtio-gpu discovery/capability walk complete.
1. Runtime MMIO mapping complete in the QEMU-only x86_64 probe build.
1. Controlled modern VirtIO transport initialization complete.
1. GET_DISPLAY_INFO complete.
1. First 2D resource, backing attachment, scanout 0 assignment, transfer, and flush complete.
1. Scanout 1 resource, backing, transfer, flush, and distinct visual proof are present.
1. Dual-output rendering is proven, while scanout 1 connector state remains a separate diagnostic signal.
1. QEMU-only virtio-gpu output inventory, `DisplayMonitor`, `DisplayViewport`, and `DisplayRenderTarget` bridge complete for the static diagnostic patterns.
1. First single-shot compositor frame complete across both virtio-gpu backing buffers with virtual desktop clipping, per-target viewport origins, and a primary-only taskbar.
1. Controlled live presentation complete in the explicit QEMU-only `compositor-live-bounded` mode; the default probe remains diagnostic/single-shot.
1. Backend-independent display input mapping and a bounded QMP input-routing smoke are complete; the current QEMU path proves relative-global pointer movement, ordinary click/focus, and cross-boundary window dragging.
1. The live presenter retains stable resources, scanouts, backing lifetime, synchronous descriptor reclamation, per-target failure isolation, and static-pattern fallback.
1. Display Options real-output inventory bridge, separate detected/requested/active configuration records, Apply/Cancel semantics, and compact backend diagnostics are complete.
1. Bounded transactional Extend/Mirror layout, primary selection, window clamping, rollback, and persistence reconciliation are complete in the shared compositor configuration path.
1. Versioned typed guest display command/response, one-slot service serialization, hosted and bare-metal adapters, safe-point routing, and stale-response protection are complete.
1. Real QEMU active query, Extend/Mirror cycling, primary/taskbar switching, per-stage captures, and one-shot rollback proof are complete through the public service endpoint.
1. Full-target transfer/flush remains a temporary whole-target implementation; dirty rectangles are deferred.
1. Real hardware remains Mule Territory.

## Gates

- `GXOS_SYNTHETIC_DUAL_MONITOR=1` enables the synthetic dual-monitor desktop model.
- `GXOS_SYNTHETIC_DUAL_WINDOW_OUTPUT=1` enables hosted dual-window output only when the first gate is also on.
- Normal hosted mode remains the default when both gates are unset.

## QEMU Virtio-GPU Content and Presentation Modes

The QEMU probe keeps three explicit content/presentation modes:

- `diagnostic-patterns`: the conservative default, with the known-good static patterns and fallback.
- `compositor-single-frame`: the preserved one-shot guideXOS compositor proof across both operational targets.
- `compositor-live-bounded`: an explicit `GXOS_QEMU_VIRTIO_GPU_COMPOSITOR_LIVE` proof that also requires `GXOS_QEMU_VIRTIO_GPU_PROBE_ACTIVE`; the automated smoke selects `GXOS_QEMU_VIRTIO_GPU_COMPOSITOR_LIVE_BOUNDED` and stops at 60 presentation attempts or 800 PIT ticks.

The live presenter is scheduler-owned but compositor-state-independent. It consumes the existing desktop invalidation bridge: `desktop::needs_redraw()` advances a monotonic redraw generation, and the presenter compares that generation with the last presented generation. Window changes, focus/z-order changes, taskbar or clock changes, desktop redraws, and explicit redraw requests therefore remain normal compositor causes. The live diagnostic marker requests redraw through that same bridge and is clipped to each target’s viewport work area; it does not become product UI and does not touch the primary-only taskbar.

Presentation is capped at 10 FPS with a hard PIT-tick interval. Each dirty generation renders target 0 and target 1 synchronously from the same generation, transfers and flushes each complete target rectangle, and reclaims its descriptor chain before the next target. Clean generations and calls inside the interval are skipped. The stable resource IDs, scanout assignments, attached backing stores, dimensions, pitch, and `PixelSurface` descriptors remain valid for the live interval. Slow queue polling does not run while desktop state is owned by the presenter.

This phase intentionally uses whole-target transfer/flush rather than dirty rectangles. A failure on one target is recorded with its frame, target, command, response, and timeout state while the other target continues when safe. After a small bounded failure streak, the affected target may repaint the known-good static pattern; the other resource is not reset or collapsed into the primary virtual region. Fallback activation and stop reason are part of the compact live summary.

The bounded QEMU harness captures `initial-head0.png`, `initial-head1.png`, `final-head0.png`, and `final-head1.png`, records SHA-256 checksums and changed status, and verifies guideXOS content, the 2560x800 viewport split, and primary-only taskbar behavior. The `compositorInputBounded` extension additionally captures `input-click-head*.png`, `input-boundary-head*.png`, and `input-after-drag-head*.png`. It must never be used as an unrestricted production boot mode. Cursor queues, cursor commands, display hotplug, per-monitor taskbars, and arbitrary runtime mode setting remain deferred from the low-level probe.

## Validated Modes

| Mode | `presentationMode` | `renderTargetCount` | `backedTargetCount` | `dualWindowOutput` | What was proven |
| --- | --- | ---: | ---: | --- | --- |
| `normal-single-output` | `normal-single-output` | 1 | 1 | `false` | Default hosted behavior stays unchanged. |
| `synthetic-camera` | `synthetic-camera` | 2 | 1 | `false` | Monitor 2 is modeled at virtual origin `1920,0` and no secondary hosted window is created. |
| `synthetic-two-window-output` | `synthetic-two-window-output` | 2 | 2 | `true` | Target 1 uses origin `0,0` with the taskbar visible, target 2 uses origin `1920,0` with the taskbar suppressed, and input mapping is correct. |

For the dual-window mode, the validated input mapping was:

- primary local `x=120` maps to virtual `x=120`
- secondary local `x=120` maps to virtual `x=2040`

## How To Launch

Preferred launcher:

```bat
.\run-hosted-synthetic-dual-window.bat
```

Equivalent manual launch:

```powershell
$env:GXOS_SYNTHETIC_DUAL_MONITOR = '1'
$env:GXOS_SYNTHETIC_DUAL_WINDOW_OUTPUT = '1'
.\run-server.bat
```

If both gates are unset, `.\run-server.bat` stays in normal single-output mode.

## Validation

| Command | What it proves |
| --- | --- |
| `build.bat` | The hosted runtime and display code compile successfully. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-display-synthetic-layout.ps1` | The synthetic gate plumbing, display-model helpers, render-target wiring, and summary diagnostics are present and consistent. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-hosted-display-runtime.ps1` | All three validated runtime modes behave as expected, including summary logs, paint routing, input mapping, and cleanup. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-qemu-display-probe.ps1` | The QEMU probe confirms Stage A visually, validates the physical backing contract, captures distinct Stage B patterns on scanout 0 and scanout 1, and records the split between connector state, operational output readiness, presentation confirmation, and the one-shot compositor proof. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-compositor-frame.ps1` | The QEMU-only compositor-frame smoke renders one static guideXOS desktop snapshot into both virtio-gpu outputs, validates target-local clipping and the primary-only taskbar, and preserves the static-pattern fallback path. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-live-presentation.ps1` | Source and bounded QEMU smoke for the explicit live gate: dirty-aware repeated presentation, 10 FPS cap, 60-attempt bound, initial/final head captures, checksum change, both targets, and primary-only taskbar. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-input-routing.ps1` | Source safety smoke for the backend-independent mapper and bounded QEMU input proof. Add `-Runtime` for the PS/2-relative click/focus, cross-boundary drag, both-output capture, and live-presentation proof. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-mmio-mapping.ps1` | The generic MMIO mapping API contract, safety flags, and virtio-gpu probe wiring stay aligned with the runtime mapping prerequisite. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-diagnostic-source.ps1` | The virtio-gpu probe source keeps the full capability walk, the `cfg_type=0x05` diagnostic-only treatment, QEMU-only gates, bounded polling, response validation, the diagnostic/single-shot modes, the bounded live bridge, and the no-real-hardware constraint. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-output-backend.ps1` | The QEMU-only virtio-gpu output backend keeps connector state separate from operational readiness, bridges into `DisplayMonitor` / `DisplayViewport` / `DisplayRenderTarget`, and preserves the diagnostic, single-shot, live, and fallback boundaries. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-display-options.ps1` | Source contract for QEMU-only gates, separate detected/requested/active models, transactional pause/rebuild/validation/rollback, Extend/Mirror geometry, primary/taskbar routing, and safe persistence. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-qemu-display-options-runtime.ps1` | Bounded QEMU runtime wrapper for the real output inventory, both live targets, output captures, validation counters, and per-target GPU-failure reporting. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-display-configuration-control-plane.ps1` | Source contract smoke for the versioned command/response, bounded service, hosted and bare-metal adapters, transaction ordering, rollback, persistence gating, QEMU-only injection, and prohibited-feature exclusions. |
| `powershell -ExecutionPolicy Bypass -File scripts\smoke-virtio-gpu-display-configuration-control.ps1` | Bounded QEMU runtime proof for active query, Mirror/Extend cycling, primary/taskbar switching, one-shot rollback, per-stage dual-head captures, and zero GPU failures/fallback. |
| `build-kernel.bat` | The bare-metal service, adapter, and QEMU coordinator compile and link. |
| `git diff --check` | The working tree is free of whitespace and patch-format issues. |

The hosted runtime smoke restores `desktop.json` and `desktop.state` and removes `display-options.cfg` as part of its cleanup, so validation does not leave those runtime state files dirty.

## Current Architecture Terms

- `DisplayMonitor` here means the code-level `DisplayMonitorDescriptor` concept: one monitor record with virtual coordinates, size, enabled/primary flags, and virtual bounds.
- `DisplayViewport` is the active hosted view into the virtual desktop; it tracks the active origin, size, synthetic-hosted state, preferred geometry, assigned geometry, and local-to-virtual coordinate conversion.
- `DisplayRenderTarget` is one renderable target entry; it records the target index, monitor mapping, viewport origin, and whether the target is backed by a hosted framebuffer or an output resource.
- For the QEMU virtio-gpu path, those descriptors now carry separate connector state, resource binding, transfer readiness, present readiness, and presentation confirmation flags.
- `virtual desktop bounds` are the aggregate rectangle reported by `DisplayVirtualDesktop::left`, `top`, `right`, `bottom`, `width()`, and `height()`.
- `backed render target` means the target has a hosted framebuffer backing.
- `conceptual render target` means the target exists in the model and diagnostics even when it is not backed in single-window synthetic-camera mode.

## Intentionally Deferred

- Hardware multi-output
- Real-hardware multi-output
- Per-monitor taskbars
- Per-monitor wallpaper
- VNC/video multi-target capture
- Cursor warping and advanced focus semantics
- Real hotplug, refresh rate, rotation, and DPI behavior

## Known Limitations

- This is a hosted synthetic experiment, not real hardware multi-monitor support.
- QEMU virtio-gpu scanout 0 and scanout 1 each receive the compositor snapshot and bounded live updates; connector state remains a separate diagnostic signal from operational output readiness.
- The second hosted window is still synthetic, not a hardware-backed second display.
- Default hosted mode stays single-output unless the gates are enabled.

## Current Paging Inventory

The runtime MMIO work is starting from the existing huge-page / page-table scaffolding, not from a blank slate.

- `kernel/core/include/kernel/hugepages.h` defines the current x86-64 and ARM64 page-table flag vocabulary, including writable, user, cache-disable, write-through, write-combining, and no-execute bits.
- `kernel/core/hugepages.cpp` already contains the huge-page-oriented helpers: `map2M`, `map1G`, `unmap2M`, `unmap1G`, `make_pde_2m`, `make_pdpe_1g`, `split_2m_to_4k`, and `split_1g_to_2m`.
- Those helpers establish the shape of the eventual mapping path, and the current QEMU-only runtime MMIO window now layers on top of that scaffolding.
- The active x86_64 probe build uses a reserved high-half MMIO window with UC-style `PCD|PWT` leaf mappings, `NX`, supervisor-only permissions, and a bounded bump allocator.
- The page-table writer stores physical child-table addresses in hardware entries, and the probe enables `EFER.NXE` before it emits NX-marked MMIO leaves; if NXE is unavailable, the probe stops before touching the BAR.
- PAT/MTRR cache-attribute plumbing is still unresolved globally, so the safe current phase uses the UC-compatible `PCD|PWT` path instead of mapping PCI MMIO as ordinary cacheable RAM.
- `kernel::mmio::mapForDevice` now installs the QEMU-only transport mappings and stops before any transport write path if it cannot prove a safe MMIO window.
- The same mapping path now feeds the controlled virtio-gpu transport init milestone, but only behind the diagnostic QEMU gate.

## QEMU / Bare-Metal Output Investigation

This phase records the backend matrix plus the QEMU-only resource-backed output path; the boot path itself still does not gain real-hardware multi-output rendering.

### Observed Backend Matrix

| Backend | QEMU args | Booted? | GOP handles | Raw descriptors | Unique candidates | Result | Interpretation |
| --- | --- | --- | ---: | ---: | ---: | --- | --- |
| `std` | `-vga std` | yes | 2 | 2 | 1 | `FramebufferCount=2`, `DuplicateFramebufferCount=1` | Two GOP handles alias the same framebuffer memory. Descriptor `1` is not a second monitor. |
| `virtio-gpu` | `-vga none -device virtio-gpu-pci,max_outputs=2` | yes | 2 | 0 | 0 | `BootInfo array disabled`, kernel `FramebufferCount=0` | The bootloader rejects the selected GOP framebuffer with `unsupported-pixel-format` after a `1280x800` snapshot with `base=0`, `pitch=0`, `bpp=0`, `format=Unknown`. |
| `virtio-vga` | `-vga virtio` | yes | 2 | 2 | 1 | `FramebufferCount=2`, `DuplicateFramebufferCount=1` | Same alias pattern as `-vga std`; no additional unique framebuffer candidate. |
| `qxl-vga` | `-vga qxl -spice addr=127.0.0.1,port=5930,disable-ticketing=on` | yes | 2 | 2 | 1 | `FramebufferCount=2`, `DuplicateFramebufferCount=1` | QXL/SPICE is usable as a diagnostic probe, but it still collapses to one unique framebuffer candidate through GOP. |

Fresh backend evidence is captured in `logs\qemu-display-probe-20260712-214504\qemu-display-probe.evidence.txt`.

Current takeaways:

- `std`, `virtio-vga`, and `qxl-vga` all expose two GOP handles, but only one unique framebuffer candidate. The second handle is a duplicate alias, not a second monitor.
- `virtio-gpu-pci,max_outputs=2` and the optional modern-only `disable-legacy=on` variant now both expose the modern VirtIO PCI capability set, and the probe now maps the transport window read-only before starting the QEMU-only 2D render milestones.
- `virtio-vga` still resolves the same capability set, so the transport mapping is now the first diagnostic boundary rather than a one-off command-line quirk.
- The full capability walk now logs every vendor-specific VirtIO capability, including `cfg_type=0x05`, and it keeps scanning for common, notify, ISR, and device config capabilities even when the PCI config capability is malformed.
- The bootloader still reaches the kernel on the virtio-gpu path, so this is not a boot-before-handoff problem. The current boundary is the read-only transport probe, not GOP discovery.
- The current QEMU probe path now creates a 2D resource, attaches DMA-visible backing memory, assigns scanout 0, transfers a deterministic CPU-generated test pattern, and flushes it.
- Stage B adds a second independently backed 2D resource, assigns scanout 1, transfers the secondary pattern, and flushes it, but QEMU still does not report scanout 1 as enabled.
- Hardware multi-output remains unimplemented in guideXOS. The QEMU probe path is separate from real hardware and now consumes the compositor snapshot through the explicitly gated bounded live presenter.

The new probe launchers are:

- `scripts\run-qemu-display-probe.bat`
- `scripts\run-qemu-multimonitor-probe.bat`

The smoke harness is:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\smoke-qemu-display-probe.ps1
```

It boots QEMU headlessly, captures the probe's serial output into `logs\qemu-display-probe-<timestamp>\`, and stops QEMU automatically once the framebuffer diagnostics have been observed.

The standard `std` mode still validates:

- `GOP handles discovered`
- `BootInfo FramebufferCount`
- `UniqueFramebufferCount`
- `DuplicateFramebufferCount`
- descriptor `0` as `primary selected`
- descriptor `1` as `duplicate alias same-as-primary` when present
- the kernel's mirror of the same counts
- the kernel's `Framebuffer ready` marker, which shows the primary framebuffer is still the render target

### What guideXOS cannot use yet

- Multiple framebuffer descriptors are not part of the current boot handoff contract.
- The kernel does not yet consume an array of framebuffer targets from the boot path.
- The compositor does not yet render to more than one real framebuffer in bare-metal mode.
- The QEMU-only virtio-gpu path now has bounded single-shot, live, and relative-global interactive compositor proofs; head-aware absolute routing is unavailable with the current PS/2 launcher path, and normal product multi-output behavior remains deferred.

### Next roadmap milestone

The next implementation milestone is virtio-gpu display configuration-change
events, safe output hotplug inventory refresh, EDID retrieval where supported,
mode-catalog refinement, dirty-rectangle presentation, manual interactive QEMU
validation, and eventual real-hardware backend planning under a separate Mule
checkpoint. Physical timing, refresh control, rotation, arbitrary mode setting,
and head-aware absolute QMP routing remain unavailable. Real-hardware GPU
enablement remains Mule Territory.

## Virtio-GPU Driver Investigation

Diagnostic-only probe results from `logs\qemu-display-probe-20260709-211742\virtio-gpu\serial.log` and `logs\qemu-display-probe-20260709-211742\virtio-gpu-modern-only\serial.log`:

| Item | Result |
| --- | --- |
| PCI discovery | Success. The probe found a virtio-gpu PCI function at `00:02.00` with `vendor=0x1AF4`, `device=0x1050`, `subsystem=0x1AF4:1100`, `class=0x03`, `subclass=0x80`. |
| Capability walk | Success. The full PCI capability list walk logs 6 caps, 5 vendor-specific caps, and every vendor-specific VirtIO capability. `cfg_type=0x01` common, `0x02` notify, `0x03` ISR, and `0x04` device are resolved. `cfg_type=0x05` is diagnostic evidence only and is not treated as success by itself. On `virtio-gpu` and `virtio-gpu-modern-only`, the PCI config capability is malformed because BAR0 is unassigned. |
| Modern transport | Detected and mapped in the QEMU-only probe build. The common config BAR resolves to `0x000000C000000000`, the transport MMIO window is mapped into the reserved kernel range, and the probe now continues into bounded status progression. |
| Feature negotiation | Complete for `VIRTIO_F_VERSION_1` and the minimal modern transport feature set. |
| Control queue | Ready. Queue 0 is configured and enabled; the cursor queue stays disabled. |
| GET_DISPLAY_INFO | Success. One diagnostic control command is issued before the render milestone and one more after flush. |
| Scanouts reported | `deviceConfigNumScanouts=2`, `slots=16`, `enabled=1`, `disabled=15`, `qemuMaxOutputsIntent=2`, `qemuTwoUsableScanouts=no` in the current QEMU run. |
| Stage B initial state | Success. The latest Stage B probe logs `scanout1InitialEnabled=no` before the second resource is created, while still confirming `deviceConfigNumScanouts=2` and `qemuMaxOutputsIntent=2`. |
| Stage B activation | Success on the guest side. A second resource and backing store are created, scanout 1 is assigned, transferred, and flushed, and the static diagnostic pattern is visibly distinct. `GET_DISPLAY_INFO` still reports `enabledScanoutsAfter=1` and `scanout1 enabled=no`, but that connector state is tracked separately from operational readiness. |
| Output inventory | Success. The operational output inventory now reports two outputs, two monitors, and two backed render targets; `connectorEnabled=1` and `presentationConfirmed=2` are tracked separately from `GET_DISPLAY_INFO.enabled`. |
| Virtual desktop | Success. The virtual desktop is computed from the assigned scanout rectangles, so the current `1280x800` outputs land at `0,0` and `1280,0` with a combined `2560x800` desktop. |
| Visual proof | The Stage B capture artifacts at `logs\qemu-display-probe-20260712-214504\virtio-gpu-stageB\captures\scanout0-stageB.png` and `logs\qemu-display-probe-20260712-214504\virtio-gpu-stageB\captures\scanout1-stageB.png` were manually inspected and are distinct. |
| Resource / backing | Success. Stage A creates one `B8G8R8X8_UNORM` 2D resource with bounded DMA-visible backing, and Stage B creates a second independent resource with its own backing store. |
| Scanout 0 assignment | Success. The diagnostic resource is assigned to scanout 0 before Stage B adds the second scanout. |
| Transfer / flush | Success. Stage A transfers and flushes the primary pattern; Stage B separately transfers and flushes the secondary pattern. |
| Modern-only QEMU mode | Supported locally. The smoke successfully launches `-device virtio-gpu-pci,max_outputs=2,disable-legacy=on`. |
| Current interpretation | QEMU exposes a modern virtio-gpu PCI candidate, guideXOS proves the safe QEMU-only transport initialization milestone plus both scanout diagnostic render milestones, and the output inventory records two operational outputs while `GET_DISPLAY_INFO` keeps connector state separate. The one-shot compositor proof and the controlled bounded live presenter both render through the two operational targets with static fallback preserved. |

Next roadmap milestone:

- Resolution and output-mode selection.
- Safe resource rebuild/resizing.
- Virtio-gpu display events/config-change handling.
- Hotplug.
- Dirty-rectangle presentation.
- Manual interactive QEMU validation.
- Eventual real-hardware backend planning under a separate Mule checkpoint.
- Real hardware stays Mule Territory.

## Virtio-GPU Transport Milestone

The virtio-gpu discovery path now maps the modern transport MMIO regions into a reserved kernel window, performs bounded modern status progression, negotiates the minimal feature set, configures controlq 0, completes the diagnostic `GET_DISPLAY_INFO` requests, and carries the QEMU-only scanout-0 and scanout-1 diagnostic render milestones.

- PCI discovery still finds the QEMU virtio-gpu function at `00:02.00`.
- The modern VirtIO capability walk still resolves `common`, `notify`, `isr`, and `device` capabilities.
- The `pci` capability remains malformed in the current QEMU setup because BAR0 is unassigned, and it is still not treated as a transport region.
- The active x86_64 probe build gates runtime mapping behind `GXOS_QEMU_VIRTIO_GPU_PROBE_ACTIVE`.
- `kernel::mmio::mapForDevice` installs the common, notify, ISR, and device config regions into the reserved kernel MMIO window using supervisor-only, non-executable, UC-style `PCD|PWT` leaf mappings.
- The current cache policy avoids ordinary write-back RAM semantics and does not touch global MTRRs.
- The probe now performs bounded reset/status progression, requires `VIRTIO_F_VERSION_1`, writes the minimal driver feature set, verifies `FEATURES_OK`, and configures only control queue 0.
- `GET_DISPLAY_INFO` now runs before rendering and again after flush, and both responses are parsed.
- The current QEMU run reported `deviceConfigNumScanouts=2`, `slots=16`, `enabled=1`, `disabled=15`, `qemuMaxOutputsIntent=2`, and `qemuTwoUsableScanouts=no` even after the second resource and flush completed; that remains a connector-state diagnostic, not a statement about operational output readiness.
- The probe now creates one `B8G8R8X8_UNORM` 2D resource for scanout 0, then a second independent 2D resource for scanout 1, attaches bounded DMA-visible backing memory to both, transfers deterministic test patterns, flushes them, and publishes an operational output inventory with two monitors and two backed render targets.
- The render path stays QEMU-only, uses the reserved diagnostic resources, and does not set up cursor, virgl, blob, 3D, or context integration; the controlled single-shot and bounded-live compositor proofs share this 2D resource path.
- Unmap currently clears only MMIO-owned leaf entries and retains the intermediate page-table pages for now.

## Runtime MMIO Window

- Base: `0xFFFFC00000000000`
- Size: `16 MiB`
- Allocation strategy: a bounded bump allocator over the reserved high-half window, with per-page conflict checks and no automatic recycling yet.
- Architecture gate: x86_64 QEMU probe builds only.
- Build gate: `GXOS_QEMU_VIRTIO_GPU_PROBE_ACTIVE`
- Page-table flags: present, supervisor-only, writable leaf, `NX`, `PCD`, and `PWT`
- `NX` is only used after the probe confirms `EFER.NXE` can be enabled on the QEMU-only build.
- Cache strategy: UC-compatible `PCD|PWT`, not write-back
- Unmap limitation: only MMIO-owned PTEs are cleared; shared higher-level paging structures are retained

### Next Intended Phase

- Interactive manual mouse validation.
- Display Options integration with the real virtio-gpu backend.
- Persistent Extend/Mirror configuration and primary-monitor switching are now complete through the authoritative typed service.
- VirtIO-GPU display configuration-change events and safe output inventory refresh.
- EDID retrieval where supported and mode-catalog refinement.
- Dirty-rectangle optimization.
- Real hardware remains Mule Territory.

## Framebuffer Array Handoff

The bootloader and kernel now preserve a bounded diagnostic framebuffer array in `BootInfo`, but the legacy single-framebuffer fields remain the authoritative rendering contract.

- `FramebufferBase`, `FramebufferSize`, `FramebufferWidth`, `FramebufferHeight`, `FramebufferPitch`, and `FramebufferFormat` still describe the primary framebuffer that the renderer uses today.
- `FramebufferCount` is the raw GOP descriptor count, `FramebufferUniqueCount` is the deduplicated physical framebuffer count, `FramebufferDuplicateCount` counts exact aliases, and `FramebufferSuspiciousCount` records same-base/same-size collisions with mismatched geometry or format.
- `FramebufferDescriptors[]` preserve the raw GOP descriptors so the boot path can classify aliases without changing rendering behavior.
- UEFI GOP can populate more than one descriptor if firmware or QEMU exposes multiple usable handles.
- BIOS / Multiboot remains a single-descriptor handoff with `FramebufferCount = 1`.
- Secondary framebuffer rendering stays deferred until the bare-metal compositor grows explicit multi-target present support.
- Deduplication prevents guideXOS from treating aliased GOP handles as separate monitors.
- The optional `virtio-gpu` comparison path remains QEMU-only and does not change the boot handoff contract. Boot handoff still reports `unsupported-pixel-format`; the separate kernel-side resource path now proves two operational output targets and controlled single-shot/bounded-live presentation without enabling a real-hardware multi-output compositor.

## Bare-Metal Display Target Inventory

The kernel now derives a read-only inventory of unique framebuffer-backed display candidates from the preserved BootInfo descriptors.

- Raw BootInfo descriptors stay intact for diagnostics, while duplicate and alias entries are excluded from the candidate list.
- The inventory bridges into the display model using disabled `DisplayMonitorDescriptor` candidates for anything that is not the preserved primary/selected framebuffer.
- Current QEMU `-vga std`, `-vga virtio`, and `-vga qxl` all expose `FramebufferCount=2`, but the deduplicated inventory reports `UniqueCount=1`, `ActiveRenderTargetCount=1`, and `DisabledCandidateCount=0`.
- Rendering remains primary-only in bare-metal mode.
- If later hardware proof finds additional distinct framebuffers, those extra candidates should remain disabled until a future risky phase explicitly promotes them into active render targets.

## Next Recommended Steps

- Keep the synthetic path isolated and continue using the existing smoke tests as the regression fence.
- Keep the diagnostic patterns and single-shot proof as explicit fallbacks while validating the bounded live path.
- Run manual interactive QEMU validation of the Display Options inventory, Extend/Mirror transaction, primary switch, and persistence across two launches.
- Add VirtIO-GPU display configuration-change events and safe output inventory refresh.
- Refine the bounded mode catalog and add EDID retrieval where supported after a separate safety review.
- Optimize whole-target transfers with dirty rectangles later.
- Keep head-aware absolute QMP routing explicitly unavailable until QEMU exposes a verified source-head path.
- Keep real hardware enablement marked as Mule Territory and preserve the fallback behavior contract.

## QEMU Input Routing Milestone (2026-07-13)

The input path was inventoried before changing the launcher. `scripts\run-qemu-display-probe.bat` uses `-machine q35,usb=off`, does not add a USB tablet or virtio-input device, and keeps the `virtio-gpu-pci,id=gpu0,max_outputs=2` GTK frontend. Therefore the current interactive guest path is `ps2-relative`: PS/2 packet deltas are accumulated against one global virtual cursor. The smoke records the installed QEMU version, graphical arguments, `gpu0`, head count, QMP port, and the result of QMP schema/device queries. QMP is only a deterministic test injector; the kernel does not depend on QMP.

`DisplayInputMapper` is backend-independent and consumes the runtime `DisplayMonitor` geometry. It keeps source head and monitor ID separate, maps head-local absolute coordinates through monitor virtual origins, scales normalized absolute ranges with signed 64-bit intermediates, and clamps the global cursor to the aggregate virtual desktop. For the current two `1280x800` monitors, head 0/local `100,200` maps to virtual `100,200`; head 1/local `100,200` maps to virtual `1380,200`. The dimensions and origins are read from descriptors, not hardcoded. Relative input remains global across the `x=1280` boundary. An absolute event without a source head uses the last active monitor or the primary monitor and emits an explicit fallback reason.

The QEMU-only proof adapter feeds the mapped events into the ordinary `KernelCompositor` hit-test, focus, title-bar drag, and capture state. It creates one bounded ordinary window titled `QEMU Input Proof`, draws a small software diagnostic cursor marker through the compositor, and does not use a virtio-gpu cursor queue or hardware cursor command. The bounded QMP sequence performs a head-0 click/focus attempt, then moves through several relative steps while dragging across the runtime boundary. The proof records the initial, boundary-crossing, and final window rectangles, pointer/active-monitor transitions, button-up cleanup, target captures, and live presentation counters.

The required result line is intentionally explicit about the capability boundary:

```text
Dual-monitor input proof: relativeGlobal=ok headAwareAbsolute=unavailable reason=guest-input-path-ps2-relative-no-source-head ...
```

If a future QEMU exposes source-head routing, the same mapper can consume head-local or normalized absolute events and report the corresponding `sourceHead=0/1`, `monitor=1/2`, local, and virtual coordinates. If head-1 routing cannot be established, the smoke retains the relative-global result and reports the precise missing capability; it does not claim a head-aware absolute proof.

Presentation diagnostics now separate `presentationPolls`, `eligibleAttempts`, `boundedProofIterations`, `renderedFrames`, `cleanSkips`, and `rateLimitSkips`. `rateLimitSkips` counts scheduler polls rejected by the hard rate interval and can exceed the bounded proof iteration count; the working 10 FPS cap and 60-attempt bound are unchanged.

Runtime capture evidence is stored under the timestamped QEMU run root, for example:

```text
logs\qemu-display-probe-<timestamp>\virtio-gpu-compositorInputBounded\captures\initial-head0.png
logs\qemu-display-probe-<timestamp>\virtio-gpu-compositorInputBounded\captures\input-boundary-head0.png
logs\qemu-display-probe-<timestamp>\virtio-gpu-compositorInputBounded\captures\input-after-drag-head1.png
```

The remaining limitations are fixed assigned output dimensions, no arbitrary
mode setting, no display hotplug/config-change path, the current PS/2-relative
QEMU path with no head-aware absolute source identity, no real-hardware
GPU/MMIO path, no virtio-gpu cursor queue, no hardware cursor commands, and no
unrestricted production enablement. The next roadmap milestone is resolution
and output-mode selection, safe resource rebuild/resizing, virtio-gpu display
events/config-change handling, hotplug, dirty-rectangle presentation, manual
interactive QEMU validation, and eventual real-hardware backend planning under
a separate Mule checkpoint. Real-hardware GPU enablement remains Mule
Territory.

## QEMU Logical-Resolution Resource-Rebuild Milestone

The bounded QEMU-only mode catalog is `1280x800`, `1024x768`, and `800x600`.
Each entry has a stable mode ID, preferred/current/backend-supported flags,
32-bit XRGB backing estimate, and checked overflow/minimum/maximum arithmetic.
Per-output backing is bounded to 16 MiB and the two-output total is bounded to
32 MiB. Unsupported or duplicate persisted modes are rejected without
advertising a mode the backend cannot allocate and present.

The service builds the complete requested layout first. For Extend, the
mixed-resolution proof is Display 1 `1280x800` at `0,0` and Display 2
`1024x768` at `1280,0`, with virtual desktop `2304x800`; the union-aware
cursor clamp prevents the shorter output’s lower 32 pixels from becoming a
dead region. Equal-resolution Extend returns to `2560x800`. Mirror is
compatible only when active dimensions match, with both target viewports at
`0,0`; mismatched modes are rejected as `MirrorGeometryIncompatible` before
unnecessary replacement allocation.

`VirtioGpuOutputRebuildPlan` records output identity, scanout, old/new
resource IDs and dimensions, backing requirements, target geometry, virtual
origin, preparation/attachment/scanout/validation/commit state, and cleanup
status. The lifecycle is prepare-before-replace: allocate zeroed kernel-owned
backing, verify every physical run and byte of bounded mem-entry coverage,
create and attach the replacement resource, render a validation frame, bind
and flush it, verify presentation, publish the new inventory atomically,
commit active configuration, and only then unref the old resource. Old backing
and resource IDs remain operational for rollback until commit. Lifecycle
diagnostics track created, committed, rolled-back, unreferenced, active
backing, and cleanup-failure counts; the repeated-change proof returns to the
stable two-output level with `activeBacking=2` and `cleanupFailures=0`.

The proof covers equal Extend, mixed Extend, compatible Mirror, mismatch
rejection, primary/taskbar switching after resize, second-output commit
rollback, bounded repeated changes, per-output captures, and zero GPU
failures/fallback. The stay-open manual launcher is
`scripts\run-qemu-virtio-gpu-resolution-manual.bat`; it reuses the QEMU-only
probe launcher and does not enable a physical graphics path. Manual Display
Options validation is `required`: the automated public service endpoint
exercises the same transaction, but no manual interactive UI check is claimed
here.

The source and runtime smokes are:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\smoke-virtio-gpu-resolution-rebuild-source.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\smoke-virtio-gpu-resolution-rebuild.ps1
```

## Separate-Launch Display Persistence Milestone

The typed, versioned, pointer-free display-configuration control plane and the
separate-launch persistence proof are complete in the QEMU-only backend. The
authoritative runtime proof is:

```text
Display configuration persistence proof: launch1Commit=ok launch2Load=ok outputReconcile=ok automaticRestore=ok primary2Restored=yes taskbarRestored=yes layoutRestored=yes livePresentation=yes gpuFailures=0 fallback=no result=success
```

The passing evidence is under
`logs\qemu-display-configuration-persistence-20260716-063729\`. Launch 1 and
launch 2 used distinct QEMU processes (`15824` and `9432` in that run), and
the four nonempty captures are `launch1\captures\head0.png`,
`launch1\captures\head1.png`, `launch2\captures\head0.png`, and
`launch2\captures\head1.png`.

### Storage strategy

The coordinator copies the normal boot ESP once into the timestamped evidence
root and creates one separate 64 MiB raw FAT32 configuration image. Both
QEMU launches attach the exact same image as the first emulated IDE disk; the
boot ESP remains on the second disk. The configuration image is formatted by
the host before launch 1, but the display settings are created only by the
guest through the public service in `/display.cfg`. The host does not inspect,
rewrite, or reinject the display record between launches. Launch 1 changes the
image checksum; launch 2 starts from the launch-1 checksum and restores from
the guest-written record. QEMU disk release is awaited before the evidence
fingerprint is taken.

The ordinary launcher remains q35 when no explicit persistence artifact is
provided. The persistence/control harness selects the QEMU `pc` machine only
to expose the existing kernel ATA/FAT path for this bounded storage proof; it
does not enable a real hardware display path or a new GPU feature.

### Persisted representation and identity

Format version 2 is a bounded line record with serialized size, FNV-1a
checksum, mode, primary output identity, output count, output records, virtual
desktop geometry, and presentation requirement. Output records carry the
backend-neutral stable identity fields `backendType`, `backendDeviceId`,
`scanoutId`, `logicalOrdinal`, `stableName`, and `stableId`, plus bounded
requested geometry, stable logical `modeId`, and enabled/primary state. Stable
ID, backend type/device, and scanout ID are authoritative matching fields;
requested dimensions are deliberately not connector identity. Logical ordinal
and stable name are diagnostics/reconciliation hints. Resource IDs, pointers,
MMIO addresses, physical addresses, queue addresses, and backing-store details
are never serialized.

Version 1 is tolerated as a legacy mode/primary request and rebuilt against
the detected inventory. Future versions, bad checksums, truncated data,
impossible counts, overflowing coordinates/dimensions, duplicate identities,
and invalid primary identities are rejected without creating phantom outputs.

### Startup ordering and restore transaction

Startup restoration is a bounded state machine with separate loaded, validated,
detected, reconciled, applying, applied, fallback, and complete stages. It
waits for the persistent mount, compositor/presentation services, the virtio-gpu
backend, and the operational output inventory. A saved record that arrives
before those dependencies remains pending and is applied once at the safe
point. Restore uses the same public transaction service and the named
`StartupRestore` origin: validate, pause presentation, apply the real backend
layout, update primary/taskbar/input bounds, present a validation frame, resume
presentation, and then publish active state. The service reports restored only
after the real backend transaction and validation frame succeed.

Launch 2 emits `source=persisted-store injectedByHost=no loaded=yes
reconciled=yes applied=yes mode=Extend primary=display-2
taskbarMonitor=display-2 virtualDesktop=2304x800 validationFrame=ok fallback=no`
for the per-output resolution proof. The base equal-resolution persistence
proof remains covered separately.
The launch-2 proof issues only a public active-state query; it fails if a
test-coordinator `ApplyConfiguration` injection is observed. Startup
normalization does not rewrite the persisted record.

If reconciliation or application fails, the service attempts the in-memory
last-known-good request, then a safe two-output Extend default, then the
primary-output-only path, and finally the established legacy framebuffer
fallback. Invalid/stale output identities are source-tested as a bounded case:
valid detected outputs are matched, no phantom output is created, and the
documented safe fallback is selected. Malformed-file cases are isolated from
the successful two-launch evidence artifact.

Persistence writes occur only after a successful user/test apply when the
commit flag is present, or when an explicit normalization policy requires it.
Startup restore itself does not commit again. If a write fails after a
validated active transaction, the active configuration is retained and the
response reports `persistenceCommitted=no`; it is not falsely reported as
restart-safe.

The source smoke is:

```text
powershell -ExecutionPolicy Bypass -File .\scripts\smoke-display-configuration-persistence-source.ps1
```

It covers versioning, stable identity, bounded malformed/stale handling,
startup ordering, authoritative restore origin, last-known-good fallback,
write discipline, no host launch-2 injection, and the QEMU-only safety gates.

## VirtIO-GPU Display Event Observer

The fixed-topology logical-resolution milestone is complete: equal- and
mixed-resolution Extend, compatible Mirror, mismatch rejection, rollback,
resource rebuilding, per-output persistence, and launch-2 restoration are
proven. Manual interactive Display Options validation remains required and is
not claimed complete by the automated proofs.

The QEMU-only observer models the VirtIO-GPU device configuration as packed,
little-endian fields. `events_read` is device-owned and read-only;
`events_clear` is write-to-clear. The observer writes only the recognized
`VIRTIO_GPU_EVENT_DISPLAY` bit after a successful bounded `GET_DISPLAY_INFO`
rescan, validated detected-topology publication, and a post-clear coherent
read. Unknown bits remain pending. No physical GPU/MMIO boot is eligible for
this path.

Each poll reads `config_generation`, the device configuration fields, and the
generation again, accepting only a matching bounded snapshot. Polling runs at
the existing safe backend tick with a hard 10-tick interval, coalesces display
bits, bounds retries, skips paused/rebuilding/shutdown presentation, and holds
no compositor lock during MMIO or command completion polling. Device
configuration interrupts are deliberately not enabled.

A display event obtains a detached `GET_DISPLAY_INFO` snapshot for every
bounded scanout slot, preserves `connectorEnabled` separately from operational
guest state, diffs it against the previous detected topology, and publishes a
bounded pending change through `DisplayConfigurationService`. The query
reports the generation, added/removed/changed counts, classification,
recommended action, and `automaticApplyPerformed=no`. The active mode, primary,
taskbar, assigned resolutions, virtual desktop, input bounds, resources,
scanout bindings, and persisted configuration remain unchanged. A failed
rescan retains the event for bounded retry and never clears it.

The installed QEMU 11.0.0 capability probe reports `genuineEventTrigger=unavailable`:
QMP exposes `display-update` and `display-reload`, but no documented command in
this build changes a VirtIO-GPU head topology. The runtime proof therefore
does not claim a real host event. It uses a one-shot QEMU smoke-build-only
injection path, labeled `injectedEvent=yes`, to exercise connector-state,
preferred-geometry, addition, and removal diffs through the same publication
logic.

The observer smoke commands are:

```text
powershell -ExecutionPolicy Bypass -File .\scripts\smoke-virtio-gpu-display-events-source.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\smoke-virtio-gpu-display-events.ps1
```

## User-confirmed topology reconciliation

The observer is now complete as a non-destructive publication path. Detected,
pending, requested, and active state remain separate. A pending record carries
its topology generation, change classification, added/removed identities,
active-configuration impact, user-action requirement, source, and explicit
`genuineDeviceEvent` / `injectedTestEvent` labels. Observing or refreshing a
change does not alter active resources, scanout bindings, layout, input bounds,
or persistence.

The existing typed `DisplayConfigurationService` is the only topology control
plane. It exposes bounded `QueryPendingTopologyChange`,
`PreviewTopologyReconciliation`, `ApplyPendingTopologyChange`,
`DismissPendingTopologyChange`, and `RefreshDetectedTopology` commands.
Preview is planner-only and performs no GPU mutation. Apply requires both the
pending topology generation and active configuration generation, rejects stale
requests, pauses presentation, reuses the existing transactional resource and
scanout machinery, reconciles the compositor windows/cursor/primary/taskbar,
validates a live frame, commits active state, and persists only after success.
Dismiss is generation-protected and leaves active resources and persistence
unchanged. A failed apply restores scanout bindings, resources, layout, input,
window/cursor state, and presentation while retaining the pending notification.

For an explicitly applied injected removal of secondary output 1, the bounded
proof starts in two-output Extend, clears the removed scanout provisionally,
retains its resource through validation, commits a live one-output desktop with
Display 1 still primary and hosting the taskbar, then retires the detached
resource. An explicit addition places Display 2 to the right, uses 1280x800 or
the saved supported mode, validates both targets, and restores the two-output
Extend desktop. Primary removal uses a retained-output fallback in stable
topology order before falling back to a single-output path. Invalid drag/capture
state, windows outside the monitor union, and pointers outside the union are
reconciled to valid work areas without deleting windows.

The QEMU-only coordinator uses the public service endpoint for metadata preview,
dismissal, removal, addition, and an injected post-bind failure. The passing
proof is recorded as:

```text
VirtioGPU topology reconciliation proof: metadataPreview=ok metadataDismiss=ok removalPreview=ok removalApply=ok singleOutputLive=ok additionPreview=ok additionApply=ok dualOutputRestored=ok rollback=ok activeResourcesStable=yes gpuFailures=0 genuineHotplugValidated=no injectedTopologyProof=ok result=success
```

All coordinator mutations are labeled `genuineDeviceEvent=no`,
`injectedTestEvent=yes`, and carry an injected change type and topology
generation. The one-output capture records that QEMU may still expose the
inactive host head in detected inventory; that is not treated as an active
guideXOS monitor. The standard bounded probe image has no writable guest
persistence store, so its topology proof uses `persistence=not-requested`;
the service still gates persistence after successful commit, and the existing
separate-launch persistence smokes cover the writable persistence path.

Manual UI validation is `required`, not completed: use the authoritative
`scripts\run-qemu-virtio-gpu-dual-monitor-manual.bat`, open Display Options, use the
QEMU-only Test Remove/Test Restore controls, review or keep the pending change,
then explicitly apply it and check taskbar, pointer, window dragging, and
resolution behavior. No manual interaction success is claimed here.

## Manual QEMU Validation

This release-style checkpoint adds a QEMU-only manual launcher, a human-entered
result recorder, and a QMP screenshot helper. It does not add a new display
feature or use QMP as guest IPC. The authoritative launcher is:

```text
scripts\run-qemu-virtio-gpu-dual-monitor-manual.bat
```

It reuses `scripts\run-qemu-display-probe.bat`, keeps a clearly identified
writable configuration artifact at
`logs\manual-validation\display-config-store.img`, keeps QEMU open for
interaction, and builds with separate QEMU backend/manual/proof gates. Use
`-Fresh` for a new artifact or `-ImagePath path` for an explicit artifact. The
QEMU version is:

```text
QEMU emulator version 11.0.0 (v11.0.0-12122-ga4bb4b10c9)
```

The previous manual checkpoint correctly created two GTK heads but selected a
limited live-probe lifecycle: it skipped the normal desktop/App Model path,
rendered a diagnostic snapshot, and therefore did not expose Display Options.
That was a validation-environment limitation, not a fixed-topology
dual-monitor feature regression. The corrected manual path initializes the
normal VFS, compositor, shell, taskbar, Start Menu, built-in app registry,
typed App Model dispatch, input routing, and live presenter. Display Options is
registered and verified by creating a real window through the normal public App
Model route before readiness is reported.

The expected fresh-artifact state is two live VirtIO-GPU outputs in Extend
with Display 1 primary, Display 1 at 1280x800, Display 2 at 1280x800, and a
2560x800 virtual desktop. A valid persisted configuration is restored honestly
instead of being silently replaced. Host GTK window dimensions are reported
separately from guest resource dimensions and active logical dimensions.
The guest and host banners identify
`mode=manual-dual-monitor-validation`, `backend=virtio-gpu`, `outputs=2`, the
active mode and primary, per-output resolutions, virtual desktop dimensions,
the persistence artifact, `topologyTestControls=enabled=yes`,
`topologyInjectionAvailable=yes`, `automaticProof=disabled`, and
`realHardware=no`, plus `displayOptionsRegistered=yes` and
`displayOptionsLaunchPath=normal-app-model`.

Before a human session, the bounded readiness smoke is:

```text
powershell -ExecutionPolicy Bypass -File .\scripts\smoke-virtio-gpu-manual-readiness.ps1
```

It launches QEMU headlessly, verifies two operational outputs, the normal
desktop, Start Menu, real Display Options launchability, valid logical modes,
writable persistence, available topology controls, and disabled proof, then
stops QEMU cleanly. Expected proof:

```text
Manual validation readiness: outputs=2 normalDesktop=ok displayOptions=available logicalModes=valid persistence=ready automaticProof=disabled topologyControls=available result=pass
```

Manual topology controls are injected test events and never claim genuine host
hotplug: F9 injects secondary-output removal, F10 injects secondary-output
restoration, F11 injects the bounded preferred-geometry test, and F12 clears or
dismisses pending topology state through the public service. Primary-output
removal is not exposed by this control set; record that optional case as
unsupported rather than treating secondary removal as primary removal.

The exact manual checklist is reproduced below. The launcher prints the same
item headings in the host console. Every result must be entered by a human with
`scripts\record-virtio-gpu-dual-monitor-manual-result.ps1`; the recorder never
infers PASS.

### A. Initial Extend state

Verify:

- both QEMU outputs show guideXOS desktop content;
- neither output shows an old diagnostic test pattern;
- taskbar appears only on the primary output;
- secondary output has no taskbar;
- wallpaper/background renders correctly on both;
- mouse crosses between outputs without jumping;
- cursor does not enter dead space;
- windows can be clicked and focused on both outputs.

### B. Cross-monitor window interaction

Verify:

- open or select a normal window;
- drag it from Display 1 to Display 2;
- release it on Display 2;
- focus remains correct;
- maximize targets Display 2;
- restore returns to a valid Display 2 rectangle;
- drag it back to Display 1;
- a window spanning both displays clips correctly;
- no rendering stall or static fallback occurs.

### C. Display Options inventory

Open Display Options and verify:

- two real VirtIO-GPU outputs appear;
- outputs are not duplicated by synthetic monitor entries;
- both show operational status;
- connector state is shown separately where applicable;
- current Extend/Mirror mode is correct;
- current primary output is correct;
- active resolutions are correct;
- unavailable refresh rate is clearly shown as unavailable;
- unavailable rotation is clearly shown as unavailable;
- no stale pending request is shown.

### D. Primary switching

In Extend mode:

- select Display 2 as primary;
- click Apply;
- taskbar moves to Display 2;
- taskbar disappears from Display 1;
- windows remain reachable;
- mouse still crosses correctly;
- open Display Options again and confirm Display 2 is active primary;
- switch primary back to Display 1 and verify the reverse.

### E. Mixed-resolution Extend

Apply Display 1 at 1280x800, Display 2 at 1024x768, Extend, and Display 1
primary. Verify:

- both outputs remain live;
- secondary output uses the selected logical size;
- virtual desktop reflects mixed dimensions;
- pointer does not enter the dead lower-right region outside Display 2;
- windows drag between outputs;
- maximize on Display 2 respects its smaller work area;
- no stride, color, or clipping corruption appears.

### F. Mirror validation

First attempt Mirror with mismatched resolutions. Verify Apply is rejected
clearly, the current Extend layout remains active, no output becomes black, and
no persistence change occurs. Then set both outputs to 1024x768 and apply
Mirror. Verify:

- both outputs show the same logical desktop;
- taskbar appears in the mirrored image on both;
- cursor appears at the same logical position;
- clicks/focus are consistent;
- no side-by-side virtual region remains accessible;
- return to Extend.

### G. Apply/OK/Cancel semantics

Verify:

- changing a field and clicking Cancel leaves active configuration unchanged;
- Apply changes configuration without closing Display Options;
- OK applies and closes;
- failed Apply leaves the window open;
- reopening Display Options shows actual active values;
- a previously successful Apply is not undone by later Cancel.

### H. Persistence

Apply Extend, Display 2 primary, Display 1 at 1280x800, and Display 2 at
1024x768. Exit QEMU cleanly, launch again with the same persistence artifact,
and verify:

- configuration restores automatically;
- Display 2 remains primary;
- taskbar appears on Display 2;
- mixed resolutions return;
- no host reinjection occurs;
- no fallback occurs.

### I. Pending topology UI

Using only the QEMU test controls:

1. inject a secondary-output removal;
2. open Display Options;
3. verify the pending-change banner;
4. review the proposal;
5. choose Keep Current;
6. verify active desktop does not change;
7. inject the removal again;
8. choose Apply Detected Changes;
9. verify guideXOS becomes a live one-output desktop;
10. inject secondary-output addition;
11. preview and apply;
12. verify dual-output Extend returns.

Verify injected changes are visibly identified as test events. Do not describe
this as genuine host hotplug.

### J. Primary-removal fallback

If the manual test control supports it safely, make Display 2 primary, inject
removal of Display 2, preview and explicitly apply the proposed reconciliation,
then verify Display 1 becomes primary, the taskbar moves to Display 1, and
windows and cursor remain reachable. Restore Display 2 afterward. If the
control is not exposed manually, record this item as automated-only rather than
adding a new feature.

### K. Stability

Leave live dual-output presentation running for a bounded manual observation
period. Verify no frozen output, black output, visible resource corruption,
uncontrolled CPU spin, unresponsive mouse, repaint failure, repeated fallback,
or GPU failure diagnostics. Do not claim long-duration soak testing unless a
meaningful interval was actually observed.

### Manual checkpoint record

No human Display Options session was performed in this checkpoint. Therefore
A-K are `NOT TESTED` or `BLOCKED`, not PASS. The corrected manual environment is
READY FOR HUMAN VALIDATION; the readiness smoke and infrastructure checks do
not complete the human checklist. Injected topology reconciliation remains
explicitly labeled test-only, and the installed QEMU control surface does not
claim a genuine host-generated VirtIO-GPU topology event.

The manual evidence root for the automated preflight is:

```text
logs\qemu-virtio-gpu-manual-readiness-20260718-093519
```

The launcher/screenshot evidence root exercised during this checkpoint is:

```text
logs\manual-validation-20260718-095401
```

Its captured authoritative head screenshots are
`authoritative-head0-head0.png` and `authoritative-head1-head1.png`; the guest
serial log and readiness evidence are retained there. No human checklist result
was inferred.

The manual result recorder writes timestamped text records under a selected
`logs\manual-validation-*` root and records date/time, QEMU version, branch,
HEAD, persistence artifact, checklist item, explicit status, notes, screenshot
paths, and serial-log path. Screenshot capture uses
`scripts\capture-virtio-gpu-dual-monitor-manual-screenshot.ps1` with QMP only
for `screendump` and optional clean shutdown.

Validation infrastructure defects found and fixed in this checkpoint were
limited to: a fixed shared-launcher VNC `:0` collision, compile-time gate
contamination when switching flags without a clean generated-object rebuild,
the GTK surface startup issue, and the manual launcher’s probe-only lifecycle.
The corrected launcher uses the normal desktop lifecycle, a QEMU-only software
canvas feeding the existing live VirtIO-GPU resources, public display
configuration initialization, reusable persistence, and explicit injected test
controls. These are validation-environment fixes; no interactive checklist
result is inferred from them.

Completed automated preflight and regression items: hosted, framebuffer, MMIO,
VirtIO-GPU backend/compositor/presentation/input, Display Options source/runtime,
control-plane, persistence, resolution, event observer, topology reconciliation,
and manual-readiness smokes. No manual checklist result was inferred. The
environment is classified as:

```text
Ready for human manual validation; A-K still require explicit human completion
```

### Safety and remaining limitations

This checkpoint remains QEMU-only. It does not add physical GPU support,
hardware MMIO, new VirtIO features, automatic topology application, EDID,
interrupt delivery, 3D/blobs/virgl/Venus/contexts, cursor queue support, new
resolution modes, refresh-rate control, rotation, physical modesetting, or
unrelated UI redesign.

REAL HARDWARE GPU/MMIO ENABLEMENT IS MULE TERRITORY AND REQUIRES A SEPARATE SAFETY CHECKPOINT.

## Current Limitations and Next Roadmap Milestone

This milestone intentionally has no automatic hotplug application, EDID or
`GET_EDID`, refresh-rate control, rotation, cursor queue, device configuration
interrupts, physical modesetting, 3D/virgl/Venus/blob/context support, QMP
guest IPC, or real-hardware GPU/MMIO backend. Resolution is only the bounded
QEMU logical scanout/resource/backing/target/`PixelSurface` dimension. Manual
UI validation remains `required` and is not claimed as completed by the
automated proof.

The next roadmap milestone is:

- Genuine topology-event testing when QEMU exposes a supported trigger.
- VirtIO-GPU device configuration interrupt delivery.
- EDID negotiation and retrieval if useful.
- Dirty-rectangle presentation.
- Manual fixed-topology release validation.
- Eventual real-hardware architecture under a separate Mule checkpoint.

REAL HARDWARE GPU/MMIO ENABLEMENT IS MULE TERRITORY AND REQUIRES A SEPARATE SAFETY CHECKPOINT.
